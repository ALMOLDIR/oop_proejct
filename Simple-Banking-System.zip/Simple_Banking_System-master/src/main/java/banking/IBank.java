package banking;

import java.util.ArrayList;

public interface IBank {
    static ArrayList<DebitCard> getCCardsFromDB() {
        return null;
    }
    static boolean ccSearch(String card_number, int pin){
        return false;
    }
    static Banker bankerSearch(String login, String password){
        return null;
    }
}