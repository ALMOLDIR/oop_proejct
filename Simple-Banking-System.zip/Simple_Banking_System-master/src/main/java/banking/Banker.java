package banking;

public class Banker extends Actor{
    private String name;
    private String surname;
    private String phoneNumber;
    private String password;
    private String login;
    private int id;
}