package banking;

import java.awt.*;

public class User extends Actor {
    private String name;
    private String surname;
    private String phoneNumber;
    private String password;
    private int id;
    private boolean isCreditCard;
    private boolean isDebitCard;
    private boolean isMortgageCard;

    private DebitCard debitCard;
    private MortgageCard Mcard;
    private CreditCard Ccard;
    private Boolean isLoggedIn;

    public DebitCard getCard() {
        return debitCard;
    }

    public MortgageCard getMortgageCard() {
        return Mcard;
    }

    public CreditCard getCreditCard() {
        return Ccard;
    }

    public void logIn(DebitCard targetDebitCard) {
        if (targetDebitCard != null) {
            debitCard = Bank.pullCardFromDB(targetDebitCard.getCardNumber());
            isLoggedIn = true;
        }
    }

    public void logIn(CreditCard targetCard) {
        if (targetCard != null) {
            Ccard = Bank.pullCardFromDBCredit(targetCard.getNumber());
            isLoggedIn = true;
        }
    }

    public void logIn(MortgageCard targetCard) {
        if (targetCard != null) {
            Mcard = Bank.pullCardFromDBMortgageCard(targetCard.getNumber());
            isLoggedIn = true;
        }
    }

    public void logOut() {
        debitCard = null;
        isLoggedIn = false;
    }

    public boolean isLoggedIn() {
        return isLoggedIn;
    }

    public User() {
        debitCard = null;
        isLoggedIn = false;
    }



    public boolean isCreditCard() {
        return isCreditCard;
    }

    public void setCreditCard(boolean creditCard) {
        isCreditCard = creditCard;
    }

    public boolean isDebitCard() {
        return isDebitCard;
    }

    public void setDebitCard(boolean debitCard) {
        isDebitCard = debitCard;
    }

    public boolean isMortgageCard() {
        return isMortgageCard;
    }

    public void setMortgageCard(boolean mortgageCard) {
        isMortgageCard = mortgageCard;
    }


}

