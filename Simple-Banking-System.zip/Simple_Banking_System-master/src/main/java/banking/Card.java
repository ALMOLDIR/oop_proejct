package banking;

public abstract class Card {
    double balance = 0;
    int pin = 0;
    Double getBalance() {
        return balance;
    }


    void addBalanceToDB(double amount) {

    }
    public int getPin() {
        return pin;
    }

}