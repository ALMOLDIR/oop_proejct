package banking;

import org.sqlite.SQLiteDataSource;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import static banking.Bank.*;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {

        User user = new User();
        Banker banker = new Banker();

        String fileName = "card.s3db";


        Bank.url = "jdbc:sqlite:" + fileName;
        if (!Files.isRegularFile(Paths.get(fileName))) {
            createCardsDatabase();
        }

        mainMenu:
        while (true) {
            System.out.println("Welcome to Bank System. To which account do you wanna login?");
            System.out.println("1. client");
            System.out.println("2. banker");
            int who = scanner.nextInt();

            System.out.println("1, Login");
            if (who == 1)
                System.out.println("2. Registration");

            choiceOfInitialAction(who, scanner.nextInt(), user, banker);

            if (who == 1) {
                System.out.print("1. Use bank system\r\n" +
                        "0. Exit\r\n" +
                        ">");

                switch (scanner.nextInt()) {
                    case 1:
                        System.out.println("What type of card do you want to use?");
                        System.out.println("1. Debit card");
                        System.out.println("2. Credit card");

                        switch (scanner.nextInt()) {
                            case 2 -> {
                                user.logIn(showLogInDialogueForCredit());
                                if (user.isLoggedIn()) {
                                    System.out.println("\n\rYou have successfully logged in!\n\r");
                                    int returnTo = showCardDialogue(user.getCreditCard());
                                    user.logOut();
                                    System.out.println("\n\rYou have successfully logged out!\n\r");
                                    if (returnTo == 0) break mainMenu;
                                }
                            }
//                            case 2 -> {
//                                user.logIn(showLogInDialogueForMortgage());
//                                if (user.isLoggedIn()) {
//                                    System.out.println("\n\rYou have successfully logged in!\n\r");
//                                    int returnTo = showCardDialogue(user.getMortgageCard());
//                                    user.logOut();
//                                    System.out.println("\n\rYou have successfully logged out!\n\r");
//                                    if (returnTo == 0) break mainMenu;
//                                }
//                            }
                            case 1 -> {
                                user.logIn(showLogInDialogue());
                                if (user.isLoggedIn()) {
                                    System.out.println("\n\rYou have successfully logged in!\n\r");
                                    int returnTo = showCardDialogue(user.getCard());
                                    user.logOut();
                                    System.out.println("\n\rYou have successfully logged out!\n\r");
                                    if (returnTo == 0) break mainMenu;
                                }
                            }
                        }
                        break;
                    case 0:
                        break mainMenu;
                    default:
                        System.out.println("Wrong number!\r\nTry again...\r\n\n");
                }
            }else{
                System.out.print("1. Create a credit card\r\n" +
                        "2. Create a mortgage card\r\n" +
                        "0. Exit\r\n" +
                        ">");
                switch (scanner.nextInt()) {
                    case 1:
                        System.out.println("Enter id of customer");
                        int idCustomer = scanner.nextInt();
                        printNewAccount(Bank.createCreditCard(idCustomer));
                        Bank.changeStatusOfCreditCard(idCustomer);
                        break;
                    case 2:
                        System.out.println("Enter id of customer");
                        idCustomer = scanner.nextInt();
                        System.out.println("How money do you want for mortgage?");
                        double mortgageMoney=scanner.nextDouble();
                        System.out.println("For how many months?");
                        int countOfMonth=scanner.nextInt();
                        printNewAccount(Bank.CreateMortgageCard(idCustomer,mortgageMoney,countOfMonth));
                        changeStatusOfMortgageCard(idCustomer);
                        break;
                    case 0:
                        break mainMenu;
                    default:
                        System.out.println("Wrong number!\r\nTry again...\r\n\n");
                }
            }
        }
        System.out.println("\r\nBye!");
    }


    public static void createCardsDatabase() {

        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(Bank.url);

        try (Connection con = dataSource.getConnection()) {
            try (Statement statement = con.createStatement()) {
                statement.executeUpdate("CREATE TABLE IF NOT EXISTS debit_card(" +
                        "id INTEGER," +
                        "number TEXT," +
                        "pin TEXT," +
                        "balance INTEGER DEFAULT 0" +
                        ")");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void printNewAccount(MortgageCard card) {
        System.out.println("\n\rYour card has been created\n\rYour card number:");
        System.out.println(card.getNumber());
        System.out.println("Your card PIN:");
        System.out.printf("%04d%n%n", card.getPin());
    }

    public static void printNewAccount(CreditCard card) {
        System.out.println("\n\rYour card has been created\n\rYour card number:");
        System.out.println(card.getNumber());
        System.out.println("Your card PIN:");
        System.out.println(card.getPin());
    }

    public static void printNewAccount(DebitCard debitCard) {
        System.out.println("\n\rYour card has been created\n\rYour card number:");
        System.out.println(debitCard.getCardNumber());
        System.out.println("Your card PIN:");
        System.out.println(debitCard.getPin());
    }

    public static MortgageCard showLogInDialogueForMortgage() {
        System.out.print("\n\rEnter your card number:\n\r>");
        String cardNumber = scanner.nextLine();
        System.out.print("Enter your PIN:\n\r>");
        int pin = scanner.nextInt();

        MortgageCard card = new MortgageCard();
        card.setNumber(cardNumber);
        card.setPin(pin);

        if (Bank.getCardsFromDB().contains(card)) {
            return card;
        } else {
            System.out.println("\n\rWrong card number or PIN!\r\n");
            return null;
        }
    }

    public static CreditCard showLogInDialogueForCredit() {
        scanner.nextLine();
        System.out.print("\n\rEnter your card number:\n\r>");
        String cardNumber = scanner.nextLine();
        System.out.print("Enter your PIN:\n\r>");
        int pin = scanner.nextInt();

        CreditCard card = new CreditCard();
        card.setNumber(cardNumber);
        card.setPin(pin);

        if (Bank.ccSearch(card.getNumber(),card.getPin())) {
            return card;
        } else {
            System.out.println("\n\rWrong card number or PIN!\r\n");
            return null;
        }
    }


    public static DebitCard showLogInDialogue() {
        System.out.print("\n\rEnter your card number:\n\r>");
        long cardNumber = scanner.nextLong();
        System.out.print("Enter your PIN:\n\r>");
        int pin = scanner.nextInt();

        DebitCard debitCard = new DebitCard().setCardNumber(cardNumber).setPin(pin);

        if (Bank.getCardsFromDB().contains(debitCard)) {
            return debitCard;
        } else {
            System.out.println("\n\rWrong card number or PIN!\r\n");
            return null;
        }
    }

    public static int showCardDialogue(DebitCard debitCard) {
        while(true) {
            System.out.print("\n" +
                    "1. Balance\n" +
                    "2. Add income\n" +
                    "3. Do transfer\n" +
                    "4. Close account\n" +
                    //"5. Pay for mortgage\n" +
                    "5. Log out\n" +
                    "6. Exit\n" +
                    ">");

            switch (scanner.nextInt()) {
                case 2:
                    showAddIncomeDialogue(debitCard);
                case 1:
                    System.out.println("\nBalance: " + debitCard.getBalanceFromDB() + "\n");
                    break;
                case 3:
                    doTransferDialogue(debitCard);
                    break;
                case 4:
                    debitCard.deleteCardFromDB();
                    System.out.println("\nThe account has been closed!");
                    break;

//                case 6:
//                    skipMonth();
                case 5:
                    return 2;
                case 6:
                    return 0;
                default:
                    System.out.println("Wrong number!\r\nTry again...\r\n\n");
            }
        }
    }

    public static int showCardDialogue(CreditCard card) {
        while(true) {
            System.out.print("\n" +
                    "1. Balance\n" +
                    "2. Add income\n" +
                    "3. Close account\n" +
                    "4. Log out\n" +
                    "5. Transfer money\n" +
                    "5. Skip month\n" +
                    "0. Exit\n" +
                    ">");

            switch (scanner.nextInt()) {
                case 2:
                    showAddIncomeDialogue(card);
                case 1:
                    System.out.println("\nBalance: " + card.getBalanceFromDB() + "\n");
                    break;
                case 3:
                    card.deleteCardFromDBCredit();
                    System.out.println("\nThe account has been closed!");
                    break;
                case 4:
                    return 2;
                case 5:
                    doTransferDialogue(card);
                    break;
                case 6:
                    skipMonthCredit(card);
                    break;
                case 0:
                    return 0;
                default:
                    System.out.println("Wrong number!\r\nTry again...\r\n\n");
            }
        }
    }

    public static void showAddIncomeDialogue(DebitCard debitCard) {
        double amount;
        while(true) {
            System.out.print("Enter the amount:\n>");
            amount = scanner.nextDouble();

            if (amount >= 0) break;
            else {
                System.out.println("Wrong number!\r\nTry again...\r\n\n");
            }
        }
        debitCard.addBalanceToDB(amount);
    }

    public static void showAddIncomeDialogue(CreditCard card) {
        double amount;
        while(true) {
            System.out.print("Enter the amount:\n>");
            amount = scanner.nextDouble();

            if (amount >= 0) break;
            else {
                System.out.println("Wrong number!\r\nTry again...\r\n\n");
            }
        }
        card.addBalanceToDBCredit(amount);
    }



    public static void doTransferDialogue(DebitCard debitCard) {
        long targetCardNumber;
        double moneyAmount = 0;


        targetCardNumber = showEnterTargetCardNumberDialogue(debitCard);
        if (targetCardNumber != 0) {
            moneyAmount = showEnterMoneyAmountDialogue(debitCard);
        }

        if ((targetCardNumber != 0) && (moneyAmount != 0)) {
            // transaction
            DebitCard targetDebitCard;
            targetDebitCard = Bank.pullCardFromDB(targetCardNumber);
            debitCard.addBalanceToDB(-moneyAmount);
            targetDebitCard.addBalanceToDB(moneyAmount);

            System.out.println("\nThe funds are transferred successfully.");
        }
    }
    public static void doTransferDialogue(CreditCard card) {
        long targetCardNumber;
        double moneyAmount = 0;


        targetCardNumber = showEnterTargetCardNumberDialogue(card);
        if (targetCardNumber != 0) {
            moneyAmount = showEnterMoneyAmountDialogue(card);
        }

        if ((targetCardNumber != 0) && (moneyAmount != 0)) {
            // transaction
            CreditCard targetCard;
            targetCard = pullCardFromDBCredit(String.valueOf(targetCardNumber));
            card.addBalanceToDB(-moneyAmount);
            targetCard.addBalanceToDB(moneyAmount);

            System.out.println("\nThe funds are transferred successfully.");
        }
    }


    public static long showEnterTargetCardNumberDialogue(DebitCard debitCard) {
        long targetCardNumber;

        while(true) {
            System.out.print("\n" +
                    "Enter number of the card to which the funds are to be transferred,\n" +
                    "or 0 to cancel the operation:\n" +
                    ">");
            targetCardNumber = scanner.nextLong();

            if (targetCardNumber == 0) {
                break;
            }
            if (targetCardNumber == debitCard.getCardNumber()) {
                System.out.println("You can't transfer money to the same account!");
                targetCardNumber = 0;
                break;
            }
            if (!Bank.isPassedLuhn(targetCardNumber)) {
                System.out.println("Probably you made mistake in the card number. Please try again!");
                continue;
            }
            if (!Bank.cardIsInDB(targetCardNumber)) {
                System.out.println("Such a card does not exist.");
                targetCardNumber = 0;
                break;
            }
            break;
        }
        return targetCardNumber;
    }
    public static long showEnterTargetCardNumberDialogue(CreditCard card) {
        long targetCardNumber;

        while(true) {
            System.out.print("\n" +
                    "Enter number of the card to which the funds are to be transferred,\n" +
                    "or 0 to cancel the operation:\n" +
                    ">");
            targetCardNumber = scanner.nextLong();

            if (targetCardNumber == 0) {
                break;
            }
            if (targetCardNumber == Long.parseLong(card.getNumber())) {
                System.out.println("You can't transfer money to the same account!");
                targetCardNumber = 0;
                break;
            }
            if (!Bank.isPassedLuhn(targetCardNumber)) {
                System.out.println("Probably you made mistake in the card number. Please try again!");
                continue;
            }
            if (!Bank.creditCardIsInDB(targetCardNumber)) {
                System.out.println("Such a card does not exist.");
                targetCardNumber = 0;
                break;
            }
            break;
        }
        return targetCardNumber;
    }

    public static User choiceOfInitialAction(int who, int what, User user, Banker banker){
        if (who == 1) {
            if (what == 1) {
                scanner.nextLine();
                System.out.println("Enter your phone");
                user = Bank.userSearch(scanner.nextLine());
                return user;

            } else if (what == 2) {
                scanner.nextLine();
                System.out.println("Enter your name");
                user.setName(scanner.nextLine());
                System.out.println("Enter your surname");
                user.setSurname(scanner.nextLine());
                System.out.println("Enter your phone");
                user.setPhoneNumber(scanner.nextLine());
                System.out.println("Enter your password");
                user.setPassword(scanner.nextLine());
                Bank.addCustomer(user);
                user = Bank.userSearch(user.getPhoneNumber());
                printNewAccount(Bank.createAccount(user));
                changeStatusOfDebitCard(user.getId());
                user.setDebitCard(true);

                return user;
            }
        }
        else {
            if (what == 1){
                scanner.nextLine();
                System.out.println("Enter your login");
                String login = scanner.nextLine();
                System.out.println("Enter your password");
                String password = scanner.nextLine();
                banker = Bank.bankerSearch(login, password);
                return null;
            }return null;
        }
        return null;
    }


    public static double showEnterMoneyAmountDialogue(DebitCard debitCard) {
        double moneyAmount;

        while (true){
            System.out.print("\n" +
                    "Enter how much money you want to transfer,\n" +
                    "or 0 to cancel the operation:\n" +
                    ">");
            moneyAmount = scanner.nextDouble();

            if (moneyAmount < 0) {
                System.out.println("Please, enter positive number.");
                continue;
            }
            if (moneyAmount > debitCard.getBalanceFromDB()) {
                System.out.println("Not enough money!");
                moneyAmount = 0;
                break;
            }
            break;
        }
        return moneyAmount;
    }
    public static double showEnterMoneyAmountDialogue(CreditCard card) {
        double moneyAmount;

        while (true){
            System.out.print("\n" +
                    "Enter how much money you want to transfer,\n" +
                    "or 0 to cancel the operation:\n" +
                    ">");
            moneyAmount = scanner.nextDouble();

            if (moneyAmount < 0) {
                System.out.println("Please, enter positive number.");
                continue;
            }
            if (moneyAmount > card.getBalanceFromDB()) {
                System.out.println("Not enough money!");
                moneyAmount = 0;
                break;
            }
            break;
        }
        return moneyAmount;
    }
}



