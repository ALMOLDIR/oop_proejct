package banking;

import org.sqlite.SQLiteDataSource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CreditCard extends Card{
    private String cardNumber;
    private int maxBalance = -50000;
    public int customerId;

    public void addBalanceToDBCredit(double amount) {
        String addBalanceQuery = "UPDATE credit_card SET balance = balance + ? WHERE card_number = ?";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(Bank.url);

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement(addBalanceQuery);
            preparedStatement.setString(1, String.valueOf(amount));
            preparedStatement.setString(2, cardNumber);
            try {
                preparedStatement.executeUpdate();
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addBalanceToDB(double amount) {
        String addBalanceQuery = "UPDATE credit_card SET balance = balance + ? WHERE card_number = ?";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(Bank.url);

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement(addBalanceQuery);
            preparedStatement.setString(1, String.valueOf(amount));
            preparedStatement.setString(2, cardNumber);
            try {
                preparedStatement.executeUpdate();
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public boolean deleteCardFromDBCredit() {
        if (balance >= 0) {
            String deleteCardQuery = "DELETE FROM credit_card WHERE card_number = ?";
            SQLiteDataSource dataSource = new SQLiteDataSource();
            dataSource.setUrl(Bank.url);
            boolean returnValue = false;

            try (Connection connection = dataSource.getConnection()) {
                PreparedStatement preparedStatement = connection.prepareStatement(deleteCardQuery);
                preparedStatement.setString(1, cardNumber);
                try {
                    preparedStatement.executeUpdate();
                    returnValue = true;
                } catch (SQLException exception) {
                    exception.printStackTrace();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

            return returnValue;
        }
        return false;
    }

    public String getNumber() {
        return cardNumber;
    }

    public void setNumber(String number) {
        this.cardNumber = number;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public Double getBalanceFromDB() {
        String getBalanceQuery = "SELECT balance FROM credit_card WHERE card_number LIKE ?";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(Bank.url);

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement(getBalanceQuery);
            preparedStatement.setString(1, cardNumber);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                balance = resultSet.getDouble("balance");
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return balance;
    }
    public void setBalance(double balance) {
        this.balance = balance;
    }

    public int getMaxBalance() {
        return maxBalance;
    }

    public void setMaxBalance(int maxBalance) {
        this.maxBalance = maxBalance;
    }
}


