package banking;

import org.sqlite.SQLiteDataSource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Random;

public class Bank implements IBank {
    static final Random generator = new Random();
    private static final ArrayList<DebitCard> DEBIT_CARDS = new ArrayList<>();
    public static String url;

    public static ArrayList<DebitCard> getCardsFromDB() {
        // return all cards in db & copy them to Bank.cards
        DEBIT_CARDS.clear();
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(url);

        try (Connection con = dataSource.getConnection()) {
            try (PreparedStatement preparedStatement = con.prepareStatement("SELECT number, pin, balance FROM debit_card;")) {
                try (ResultSet cardFromDb = preparedStatement.executeQuery()) {
                    while (cardFromDb.next()) {
                        DebitCard debitCard;
                        // Retrieve column values
                        long cardNumber = Long.parseLong(cardFromDb.getString("number"));
                        int pin = cardFromDb.getInt("pin");
                        double balance = cardFromDb.getInt("balance");
                        debitCard = new DebitCard().setCardNumber(cardNumber).setPin(pin).setBalance(balance);
                        DEBIT_CARDS.add(debitCard);
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return DEBIT_CARDS;
    }

    public static boolean ccSearch(String card_number, int pin) {
        String pullCardQuery = "SELECT * FROM credit_card WHERE card_number LIKE ? and pin like ?";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(url);
        CreditCard ccard = new CreditCard();

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement(pullCardQuery);
            preparedStatement.setString(1, card_number);
            preparedStatement.setInt(2, pin);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                // Retrieve card values
                ccard.setBalance(resultSet.getDouble("balance"));
                ccard.setNumber(resultSet.getString("card_number"));
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return ccard.getNumber() != null;
    }

    public static Banker bankerSearch(String login, String password) {
        String pullCardQuery = "SELECT * FROM bank_worker WHERE login LIKE ? and password like ?";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(url);
        Banker banker = new Banker();

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement(pullCardQuery);
            preparedStatement.setString(1, login);
            preparedStatement.setString(2, password);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                // Retrieve card values
                banker.setName(resultSet.getString("name"));
                banker.setSurname(resultSet.getString("surname"));
                banker.setPhoneNumber(resultSet.getString("phone_number"));
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return banker;
    }

    public static User userSearch(String phone){
        String pullCardQuery = "SELECT * FROM customer WHERE phone_number LIKE ?";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(url);
        User user = new User();

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement(pullCardQuery);
            preparedStatement.setString(1, phone);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                // Retrieve card values
                user.setName(resultSet.getString("name"));
                user.setSurname(resultSet.getString("surname"));
                user.setPhoneNumber(resultSet.getString("phone_number"));
                user.setId(resultSet.getInt("id"));
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        }
        catch (Exception ex){
            ex.printStackTrace();
        }

        return user;
    }

    public static void skipMonthCredit(CreditCard card){
        String pullCardQuery = "UPDATE credit_card SET balance = balance - ? WHERE number = ?";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(url);

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement(pullCardQuery);
            preparedStatement.setDouble(1, card.getBalance()/100);
            preparedStatement.setString(1, card.getNumber());
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
    }
    public static void changeStatusOfMortgageCard(int idCustomer) {
        String insertCardQuery = "UPDATE customer SET has_mortgage_card = ? WHERE id=?";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(url);

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement psInsertCard = connection.prepareStatement(insertCardQuery);

            psInsertCard.setInt(1, 1);
            psInsertCard.setInt(2, idCustomer);

            psInsertCard.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void changeStatusOfDebitCard(int idCustomer) {
        String insertCardQuery = "UPDATE customer SET has_debit_card = ? WHERE id=?";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(url);

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement psInsertCard = connection.prepareStatement(insertCardQuery);

            psInsertCard.setInt(1, 1);
            psInsertCard.setInt(2, idCustomer);

            psInsertCard.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void changeStatusOfCreditCard(int idCustomer) {
        String insertCardQuery = "UPDATE customer SET has_credit_card = ? WHERE id=?";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(url);

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement psInsertCard = connection.prepareStatement(insertCardQuery);

            psInsertCard.setInt(1, 1);
            psInsertCard.setInt(2, idCustomer);

            psInsertCard.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static MortgageCard pullCardFromDBMortgageCard (String targetCardNumber) {
        String pullCardQuery = "SELECT * FROM mortgage_card WHERE number LIKE ?";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(url);
        MortgageCard card = null;

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement(pullCardQuery);
            preparedStatement.setString(1, targetCardNumber);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                // Retrieve card values
                String cardNumber = resultSet.getString("number");
                int pin = resultSet.getInt("pin");
                card = new MortgageCard();
                card.setNumber(cardNumber);
                card.setPin(pin);
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return card;
    }

    public static DebitCard pullCardFromDB(Long targetCardNumber) {
        String pullCardQuery = "SELECT * FROM debit_card WHERE number LIKE ?";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(url);
        DebitCard debitCard = null;

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement(pullCardQuery);
            preparedStatement.setString(1, targetCardNumber.toString());

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                // Retrieve card values
                long cardNumber = Long.parseLong(resultSet.getString("number"));
                int pin = resultSet.getInt("pin");
                double balance = resultSet.getInt("balance");
                debitCard = new DebitCard().setCardNumber(cardNumber).setPin(pin).setBalance(balance);
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return debitCard;
    }

    public static CreditCard pullCardFromDBCredit(String targetCardNumber) {
        String pullCardQuery = "SELECT * FROM credit_card WHERE card_number LIKE ?";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(url);
        CreditCard card = null;

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement(pullCardQuery);
            preparedStatement.setString(1, targetCardNumber);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                // Retrieve card values
                String cardNumber = resultSet.getString("card_number");
                int pin = Integer.parseInt(resultSet.getString("pin"));
                resultSet.getInt("balance");
                card = new CreditCard();
                card.setPin(pin);
                card.setNumber(cardNumber);
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return card;
    }


    public static boolean cardIsInDB(Long targetCardNumber) {
        String pullCardQuery = "SELECT * FROM debit_card WHERE number LIKE ?";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(url);
        boolean retVal = false;

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement(pullCardQuery);
            preparedStatement.setString(1, targetCardNumber.toString());

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                retVal = resultSet.isBeforeFirst();
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return retVal;
    }
    public static boolean creditCardIsInDB(Long targetCardNumber) {
        String pullCardQuery = "SELECT * FROM credit_card WHERE card_number LIKE ?";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(url);
        boolean retVal = false;

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement preparedStatement = connection.prepareStatement(pullCardQuery);
            preparedStatement.setString(1, targetCardNumber.toString());

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                retVal = resultSet.isBeforeFirst();
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return retVal;
    }


    public static MortgageCard CreateMortgageCard (int customerId, double mortMoney, int counfOfMonth){
        long accountNumber = generateAccountNumber();
        int pin = generator.nextInt(10_000);

        MortgageCard card = new MortgageCard();
        card.setNumber(""+accountNumber);
        card.setPin(pin);
        card.setCustomerId(customerId);
        card.setMonthLeft(counfOfMonth);
        double monthPayment=mortMoney/counfOfMonth+(mortMoney/counfOfMonth)/100;
        card.setMonthPay(monthPayment);
        card.setTotalPay(card.getMonthPay());

        addMortgageCard(card);
        moneyFromMortgage(customerId,mortMoney);

        return card;
    }
    public static void moneyFromMortgage(int customer_id, double mortMoney) {
        String insertCardQuery = "UPDATE debit_card SET balance = balance + ? WHERE customer_id=?";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(url);

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement psInsertCard = connection.prepareStatement(insertCardQuery);

            psInsertCard.setDouble(1, mortMoney);
            psInsertCard.setInt(2, customer_id);

            psInsertCard.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static CreditCard createCreditCard(int customerId){
        long accountNumber = generateAccountNumber();
        int pin = generator.nextInt(10_000);

        CreditCard card = new CreditCard();
        card.setNumber(""+accountNumber);
        card.setPin(pin);
        card.customerId = customerId;

        addCreditCard(card);

        return card;
    }

    public static DebitCard createAccount(User user) {
        // long accountNumber =  (long) (generator.nextInt(1_000_000_000)) * 10 + 4_000_000_000_000_000L;
        long accountNumber = generateAccountNumber();
        int pin = generator.nextInt(10_000);

        DebitCard debitCard = new DebitCard().setCardNumber(accountNumber).setPin(pin);
        DEBIT_CARDS.add(debitCard);

        addCardToDb(debitCard, user);

        return debitCard;
    }

    public static void addCustomer(User user){
        String insertCardQuery = "INSERT INTO customer (name, surname, phone_number, password) VALUES (?, ?, ?, ?)";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(url);

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement psInsertCard = connection.prepareStatement(insertCardQuery);

            psInsertCard.setString(1, user.getName());
            psInsertCard.setString(2, user.getSurname());
            psInsertCard.setString(3, user.getPhoneNumber());
            psInsertCard.setString(4, user.getPassword());

            psInsertCard.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static long generateAccountNumber() {
        long accountNumber = (long) (generator.nextInt(1_000_000_000)) * 10 + 4_000_000_000_000_000L;
        /*
        String s = "123456789";
        s.charAt(i)
        */
        char[] charBuffer = Long.toString(accountNumber).toCharArray();
        char[] charBuffer1 = new char[charBuffer.length];

        for (int i = 0; i < charBuffer.length; i++) {
            charBuffer1[i] = charBuffer[charBuffer.length - 1 - i];
        }
        charBuffer = charBuffer1;

        // find the sum
        int sum = 0;
        for (int i = 0; i < charBuffer1.length; i++) {
            int digit = Character.getNumericValue(charBuffer[i]);
            // Modify each odd rank
            if (((i + 1) % 2) == 0) {
                digit *= 2;
                if (digit > 9) {
                    digit -= 9;
                }
                charBuffer[i] = Character.forDigit(digit, 10);
            }
            sum += digit;
        }

        // correct accountNumber
        int lastDigit = 0;
        if ((sum % 10) != 0) {
            lastDigit = 10 - (sum % 10);
        }
        accountNumber += lastDigit;
        return accountNumber;
    }


    public static boolean isPassedLuhn(long num) {
        char[] charBuffer = Long.toString(num).toCharArray();
        char[] charBuffer1 = new char[charBuffer.length];

        for (int i = 0; i < charBuffer.length; i++) {
            charBuffer1[i] = charBuffer[charBuffer.length - 1 - i];
        }
        charBuffer = charBuffer1;

        // find the sum
        int sum = 0;
        for (int i = 0; i < charBuffer1.length; i++) {
            int digit = Character.getNumericValue(charBuffer[i]);
            // Modify each odd rank
            if (((i + 1) % 2) == 0) {
                digit *= 2;
                if (digit > 9) {
                    digit -= 9;
                }
                charBuffer[i] = Character.forDigit(digit, 10);
            }
            sum += digit;
        }

        // correct accountNumber?
        return sum % 10 == 0;
    }

    public static void addMortgageCard(MortgageCard card) {
        String insertCardQuery = "INSERT INTO mortgage_card (card_number, pin, month_pay, month_left, surcharge, total_pay, customer_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(url);

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement psInsertCard = connection.prepareStatement(insertCardQuery);

            psInsertCard.setString(1, card.getNumber());
            psInsertCard.setInt(2, card.getPin());
            psInsertCard.setDouble(3, card.getMonthPay());
            psInsertCard.setInt(4, card.getMonthLeft());
            psInsertCard.setDouble(5, card.getSurcharge());
            psInsertCard.setDouble(6, card.getTotalPay());
            psInsertCard.setInt(7, card.getCustomerId());

            psInsertCard.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void addCreditCard(CreditCard card) {
        String insertCardQuery = "INSERT INTO credit_card (card_number, pin, balance, max_credit, customer_id) VALUES (?, ?, ?, ?, ?)";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(url);

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement psInsertCard = connection.prepareStatement(insertCardQuery);

            psInsertCard.setString(1, card.getNumber());
            psInsertCard.setString(2, "" + card.getPin());
            psInsertCard.setString(3, ""+ card.getBalance());
            psInsertCard.setString(4, ""+ card.getMaxBalance());
            psInsertCard.setString(5, ""+ card.customerId);

            psInsertCard.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void addCardToDb(DebitCard debitCard, User user) {
        String insertCardQuery = "INSERT INTO debit_card (number, pin, balance, customer_id) VALUES (?, ?, ?, ?)";
        SQLiteDataSource dataSource = new SQLiteDataSource();
        dataSource.setUrl(url);

        try (Connection connection = dataSource.getConnection()) {
            PreparedStatement psInsertCard = connection.prepareStatement(insertCardQuery);

            psInsertCard.setString(1, debitCard.getCardNumber().toString());
            psInsertCard.setLong(2, debitCard.getPin());
            psInsertCard.setDouble(3, debitCard.getBalance());
            psInsertCard.setInt(4, user.getId());

            psInsertCard.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
